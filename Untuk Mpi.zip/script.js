const pages = document.querySelectorAll(".page");

const startBtn = document.getElementById("startBtn");
const nextButtons = document.querySelectorAll(".next");
const lastBtn = document.getElementById("lastBtn");
const replayBtn = document.getElementById("replay");

const music = document.getElementById("music");
const playMusic = document.getElementById("playMusic");

let currentPage = 0;


// =========================
// PAGE SYSTEM
// =========================

function showPage(pageNumber) {

  pages.forEach(page => {
    page.classList.remove("active");
  });

  const target = document.getElementById("page" + (pageNumber + 1));

  if (target) {
    target.classList.add("active");
  }

  currentPage = pageNumber;

}


// =========================
// START + MUSIC
// =========================

startBtn.onclick = function() {

  showPage(1);

  if (music) {

    music.volume = 1;
    music.play()
    .then(() => {
      console.log("Music berjalan");
    })
    .catch((error) => {
      console.log("Music gagal:", error);
    });

  }

};


// Tombol Play Music manual

if (playMusic) {

  playMusic.onclick = function() {

    music.volume = 1;

    music.play()
    .then(() => {
      console.log("Music berjalan");
    })
    .catch((error) => {
      console.log(error);
    });

  };

}


// =========================
// NEXT BUTTON
// =========================

nextButtons.forEach(button => {

  button.onclick = function() {

    showPage(currentPage + 1);

  };

});


// =========================
// LAST PAGE
// =========================

lastBtn.onclick = function() {

  showPage(6);

};


// =========================
// REPLAY
// =========================

replayBtn.onclick = function() {

  showPage(0);

  if (music) {

    music.pause();

    music.currentTime = 0;

  }

};


// =========================
// TYPING LETTER
// =========================

const text = `
Happy birthday, Mpi. 🤍

Terimakasih sudah hadir dan menjadi seseorang yang berarti buat aku.

Semoga di umur yang baru ini kamu selalu diberikan kesehatan, kebahagiaan, dan banyak hal baik.

Tetap jadi Mpi yang aku kenal ya.
Jangan lupa makan, istirahat, dan jaga diri.

I hope this year will be kinder to you.
`;

let index = 0;

const typing = document.getElementById("typing");


function typeWriter(){

  if(index < text.length){

    typing.innerHTML += text.charAt(index);

    index++;

    setTimeout(typeWriter,40);

  }

}


document.querySelector("#page4 .next").addEventListener("click",()=>{

  setTimeout(typeWriter,500);

});